import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("escola-pu");
        EntityManager em = emf.createEntityManager();

        try {
            List<Aluno> listaDeAlunos = new ArrayList<>();
            listaDeAlunos.add(new Aluno("SEDUC - Leticia M", 17));
            listaDeAlunos.add(new Aluno("SEDUC - Julio", 17));
            listaDeAlunos.add(new Aluno("SEDUC - Lara", 17));

            em.getTransaction().begin();
            for (Aluno a : listaDeAlunos){
                em.persist(a);
            }
            em.getTransaction().commit();


            List<Aluno> alunosDoBD = em.createQuery(
                    "SELECT a FROM Aluno a ORDER BY a.nome", Aluno.class).getResultList();

            for (Aluno a : alunosDoBD) {
                System.out.println("Nome: " + a.getNome() + "| Idade: " + a.getIdade());
            }

        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
        }

    }
}